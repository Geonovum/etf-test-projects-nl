2007-07-25  Mike Botts

  * Intelligence Community Intelligence Security Marking (IC ISM) Data Element
    Dictionary Version 2.0 (30 April 2004) published by the Intelligence
    Community Metadata Working Group
  * released sensorML 1.0.0 (OGC 07-000), ic 2.0 and sweCommon 1.0.0 (from OGC 07-000)
  * sensorML/1.0.0 (OGC 07-000) references ic/2.0 and sweCommon/1.0.0

